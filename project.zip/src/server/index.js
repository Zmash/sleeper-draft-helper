// server/index.js
// Start im Dev: node server/index.js  (oder per "npm run dev" mit concurrently)
//
// Endpoints:
//   GET  /api/health          -> { ok: true, ... }
//   POST /api/validate-key    -> nutzt Header "X-OpenAI-Key", macht Mini-Call für Validierung
//   POST /api/ai-advice       -> ruft OpenAI Chat Completions mit deinem Payload auf
//
// Hinweis: Wir parsen bei /api/ai-advice bevorzugt Tool-Calls (Function Calling):
//          tools.function.name === "return_draft_advice" -> JSON.parse(arguments)

import express from 'express'
import cors from 'cors'
import OpenAI from 'openai'

const app = express()
app.disable('x-powered-by')

// JSON Body (etwas größer, falls Ranking/Board umfangreich ist)
app.use(express.json({ limit: '2mb' }))

// CORS: im Dev kommt Frontend von Vite (5173)
const ALLOW_ORIGIN = process.env.CORS_ORIGIN || 'http://localhost:5173'
app.use(cors({ origin: ALLOW_ORIGIN }))

// ---------- Utils ----------
function serializeError(err) {
  const status = err?.status || err?.response?.status || 500
  const body = {
    ok: false,
    status,
    name: err?.name || 'Error',
    message: err?.message || 'Unknown error',
  }
  // Debug-Infos im Dev
  if (process.env.NODE_ENV !== 'production') {
    if (err?.error) body.error = err.error
    if (err?.response?.data) body.responseData = err.response.data
    if (err?.stack) body.stack = err.stack
  }
  return { status, body }
}

function pickAdviceFromChoice(choice) {
  const msg = choice?.message
  // 1) Preferred: Function calling (tool_calls)
  if (Array.isArray(msg?.tool_calls) && msg.tool_calls.length > 0) {
    for (const call of msg.tool_calls) {
      if (call?.function?.name === 'return_draft_advice') {
        try {
          return {
            parsed: JSON.parse(call.function.arguments || '{}'),
            raw: '',
            tool_calls: msg.tool_calls,
          }
        } catch (_) {
          // Fallback: continue
        }
      }
    }
  }
  // 2) Fallback: Plain JSON im content
  const content = msg?.content || ''
  try {
    return { parsed: JSON.parse(content), raw: content, tool_calls: msg?.tool_calls || null }
  } catch {
    return { parsed: null, raw: content, tool_calls: msg?.tool_calls || null }
  }
}

// ---------- Health ----------
app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    env: process.env.NODE_ENV || 'development',
    node: process.version,
    allowOrigin: ALLOW_ORIGIN,
  })
})

// ---------- Key-Validierung ----------
app.post('/api/validate-key', async (req, res) => {
  try {
    const userKey = req.header('x-openai-key')
    if (!userKey) return res.status(401).json({ ok: false, error: 'Missing X-OpenAI-Key header' })

    const client = new OpenAI({ apiKey: userKey })

    // Minimaler Testcall
    const r = await client.chat.completions.create({
      model: 'gpt-4o-mini',
      max_tokens: 1,
      temperature: 0,
      messages: [{ role: 'user', content: 'ping' }],
    })

    res.json({ ok: true, model: r.model, usage: r.usage })
  } catch (err) {
    const { status, body } = serializeError(err)
    console.error('[validate-key] error:', err)
    res.status(status).json(body)
  }
})

// ---------- Haupt-Endpoint: AI Advice ----------
app.post('/api/ai-advice', async (req, res) => {
  try {
    const userKey = req.header('x-openai-key')
    if (!userKey) return res.status(401).json({ ok: false, error: 'Missing X-OpenAI-Key header' })

    const payload = req.body
    if (!payload || !payload.model || !payload.messages) {
      return res.status(400).json({ ok: false, error: 'Invalid payload: expected { model, messages, ... }' })
    }

    const client = new OpenAI({ apiKey: userKey })
    const completion = await client.chat.completions.create(payload)

    const choice = completion.choices?.[0]
    console.log('[ai-advice] tool_calls:', choice?.message?.tool_calls?.length || 0)
    console.log('[ai-advice] content len:', (choice?.message?.content || '').length)
    
    const { parsed, raw, tool_calls } = pickAdviceFromChoice(choice)

    res.json({
      ok: true,
      id: completion.id,
      model: completion.model,
      usage: completion.usage,
      raw,
      tool_calls,
      parsed,
    })
  } catch (err) {
    const { status, body } = serializeError(err)
    console.error('[ai-advice] error:', err)
    res.status(status).json(body)
  }
})

const PORT = Number(process.env.PORT) || 5174
// Auf IPv4 lauschen (vermeidet "::1" Stolpersteine im Dev)
app.listen(PORT, '0.0.0.0', () => {
  console.log(`AI server listening on http://localhost:${PORT}`)
})
