// server/prod.js (ESM, weil "type": "module")
import express from 'express'
import path from 'path'
import { fileURLToPath } from 'url'
import OpenAI from 'openai'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()
app.use(express.json({ limit: '1mb' }))

// ---- API ----
app.post('/api/ai-advice', async (req, res) => {
  try {
    const userKey = req.header('x-openai-key')
    if (!userKey) return res.status(401).json({ error: 'Missing X-OpenAI-Key header' })

    const payload = req.body
    if (!payload?.model || !payload?.messages) {
      return res.status(400).json({ error: 'Invalid payload' })
    }

    const openai = new OpenAI({ apiKey: userKey })
    const completion = await openai.chat.completions.create(payload)

    const content = completion.choices?.[0]?.message?.content || ''
    let parsed = null
    try { parsed = JSON.parse(content) } catch {}

    res.json({ ok: true, id: completion.id, model: completion.model, usage: completion.usage, raw: content, parsed })
  } catch (err) {
    res.status(err?.status || 500).json({ error: err?.message || 'AI request failed' })
  }
})

// ---- Static Frontend ausliefern ----
const distDir = path.resolve(__dirname, '../dist')
app.use(express.static(distDir))

// SPA-Fallback: alle Nicht-/api Routen -> index.html
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next()
  res.sendFile(path.join(distDir, 'index.html'))
})

const PORT = process.env.PORT || 8080
app.listen(PORT, () => {
  console.log(`Prod server running on http://localhost:${PORT}`)
})
