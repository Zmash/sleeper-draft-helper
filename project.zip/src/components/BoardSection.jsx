import React, { useState } from 'react'
import BoardToolbar from './BoardToolbar'
import FiltersRow from './FiltersRow'
import BoardTable from './BoardTable'

import AdviceDialog from './AdviceDialog'
import ApiKeyDialog from './ApiKeyDialog'
import { buildAIAdviceRequest } from '../services/ai'
import { getOpenAIKey, setOpenAIKey } from '../services/key'

export default function BoardSection({
  // --- Original-Werte ---
  currentPickNumber,
  autoRefreshEnabled,
  refreshIntervalSeconds,
  lastSyncAt,
  searchQuery,
  positionFilter,
  filteredPlayers,
  pickedCount,
  totalCount,

  // --- Original-Actions ---
  onToggleAutoRefresh,
  onChangeInterval,
  onSync,
  onSearchChange,
  onPositionChange,

  // --- AI-Advice relevante Props ---
  boardPlayers,
  livePicks,
  meUserId,
  league,
  draft,
}) {
  // --- AI Advice Dialog State ---
  const [adviceOpen, setAdviceOpen] = useState(false)
  const [adviceLoading, setAdviceLoading] = useState(false)
  const [advice, setAdvice] = useState(null)
  const [adviceError, setAdviceError] = useState(null)

  // --- API Key Dialog State ---
  const [keyDialogOpen, setKeyDialogOpen] = useState(false)
  const [keyValidating, setKeyValidating] = useState(false)
  const [keyValidationError, setKeyValidationError] = useState('')
  const [pendingAskAfterKey, setPendingAskAfterKey] = useState(false)

  // --- Debug: Request/Response im Dialog anzeigen ---
  const [adviceDebug, setAdviceDebug] = useState(null)

  // Roster-Positions robuster ermitteln
  const rosterPositions =
    (league && Array.isArray(league.roster_positions) && league.roster_positions) ||
    (league && league.settings && Array.isArray(league.settings.roster_positions) && league.settings.roster_positions) ||
    []

  const hasBoard = Array.isArray(boardPlayers) && boardPlayers.length > 0
  const disabled = false

  // Button click -> Wenn Key fehlt, Dialog öffnen; sonst direkt Anfrage starten
  async function handleAskAI() {
    const key = getOpenAIKey()
    if (!key) {
      setKeyDialogOpen(true)
      setPendingAskAfterKey(true)
      return
    }
    await doAskAIWithKey(key)
  }

  // Tatsächlicher Advice-Call (mit bereits vorhandenem, validem Key)
  async function doAskAIWithKey(userKey) {
    try {
      setAdviceOpen(true)
      setAdviceLoading(true)
      setAdviceError(null)
      setAdvice(null)
      setAdviceDebug(null)

      const payload = buildAIAdviceRequest({
        boardPlayers: boardPlayers || [],
        livePicks: livePicks || [],
        me: meUserId || '',
        league: { ...(league || {}), roster_positions: rosterPositions },
        draft: draft || null,
        currentPickNumber: Number.isFinite(currentPickNumber) ? currentPickNumber : null,
        options: { topNOverall: 60, topPerPos: 20, model: 'gpt-4o-mini', temperature: 0.2, max_output_tokens: 700 }
      })

      // Kleine Request-Zusammenfassung für Debug
      const requestSummary = summarizeRequest(payload)

      const res = await fetch('/api/ai-advice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-OpenAI-Key': userKey, // Nutzer-Key nur für diesen Request
        },
        body: JSON.stringify(payload),
      })

      const text = await res.text()
      let data = null
      try { data = JSON.parse(text) } catch { /* noop */ }

      if (!res.ok) {
        const msg = data?.message || data?.error || `HTTP ${res.status}`
        setAdviceDebug({ request: requestSummary, response: data || { text }, raw: null, tool_calls: null })
        throw new Error(msg)
      }

      // Erwartet: { ok, raw, parsed, tool_calls, usage, ... }
      let parsed = data?.parsed || null

      // Fallback: Tool-Aufrufe selbst auslesen
      if (!parsed && Array.isArray(data?.tool_calls) && data.tool_calls.length > 0) {
        const call = data.tool_calls.find(c => c?.function?.name === 'return_draft_advice')
        if (call?.function?.arguments) {
          try { parsed = JSON.parse(call.function.arguments) } catch { /* noop */ }
        }
      }

      // Fallback: raw parsen
      if (!parsed && data?.raw) {
        try { parsed = JSON.parse(data.raw) } catch { /* noop */ }
      }

      setAdvice(parsed || null)
      setAdviceDebug({
        request: requestSummary,
        response: { ok: data?.ok, id: data?.id, model: data?.model, usage: data?.usage },
        raw: data?.raw || null,
        tool_calls: data?.tool_calls || null,
      })
    } catch (e) {
      setAdviceError(e?.message || 'Unerwarteter Fehler')
    } finally {
      setAdviceLoading(false)
    }
  }

  function summarizeRequest(payload) {
    const sys = payload?.messages?.find(m => m.role === 'system')?.content || ''
    const user = payload?.messages?.find(m => m.role === 'user')?.content || ''
    const ctxMatch = user.match(/<CONTEXT_JSON>\s*([\s\S]*?)\s*<\/CONTEXT_JSON>/)
    let ctx = null
    try { ctx = ctxMatch ? JSON.parse(ctxMatch[1]) : null } catch { /* noop */ }

    const counts = ctx ? {
      overall_top: ctx?.board?.overall_top?.length || 0,
      by_pos_keys: Object.keys(ctx?.board?.by_position || {}).length,
      my_picks: ctx?.my_team?.picks?.length || 0,
      roster_pos_len: ctx?.league?.roster_positions?.length || 0,
    } : null

    return {
      model: payload?.model,
      temperature: payload?.temperature,
      max_tokens: payload?.max_tokens,
      messages: payload?.messages?.length,
      has_tools: Array.isArray(payload?.tools) && payload.tools.length > 0,
      tool_choice: payload?.tool_choice?.type || null,
      context_counts: counts,
    }
  }

  // Wird aufgerufen, nachdem der Nutzer im ApiKeyDialog "Speichern" gedrückt hat
  async function handleKeySaved(savedKey) {
    setKeyValidationError('')
    setKeyValidating(true)
    const ok = await validateKey(savedKey)
    setKeyValidating(false)

    if (!ok) {
      setOpenAIKey('')
      setKeyValidationError('API Key ungültig oder nicht autorisiert. Bitte prüfe deinen Schlüssel.')
      return
    }

    setKeyDialogOpen(false)

    if (pendingAskAfterKey) {
      setPendingAskAfterKey(false)
      await doAskAIWithKey(savedKey)
    }
  }

  // Schlanke Key-Validierung gegen separaten Endpoint
  async function validateKey(userKey) {
    try {
      const res = await fetch('/api/validate-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-OpenAI-Key': userKey },
        body: JSON.stringify({}),
      })
      return res.ok
    } catch {
      return false
    }
  }

  return (
    <section className="card">
      <div className="row between items-center wrap" style={{ gap: 8 }}>
        <h2>Draft Board</h2>

        <BoardToolbar
          currentPickNumber={currentPickNumber}
          autoRefreshEnabled={autoRefreshEnabled}
          onToggleAutoRefresh={onToggleAutoRefresh}
          refreshIntervalSeconds={refreshIntervalSeconds}
          onChangeInterval={onChangeInterval}
          onSync={onSync}
          lastSyncAt={lastSyncAt}
        />

        {/* AI-Advice Button neben der Toolbar */}
        <button
          onClick={handleAskAI}
          disabled={disabled}
          style={{
            padding: '6px 10px',
            borderRadius: 8,
            border: '1px solid #444',
            background: disabled ? 'rgba(255,255,255,0.06)' : 'transparent',
            color: 'inherit',
            cursor: disabled ? 'not-allowed' : 'pointer'
          }}
          title={disabled ? 'Board-Daten fehlen' : 'AI-Empfehlung für den nächsten Pick'}
        >
          🤖 AI Advice
        </button>
      </div>

      <FiltersRow
        searchQuery={searchQuery}
        onSearchChange={onSearchChange}
        positionFilter={positionFilter}
        onPositionChange={onPositionChange}
      />

      <BoardTable
        progressPercent={totalCount ? Math.round((pickedCount / totalCount) * 100) : 0}
        pickedCount={pickedCount}
        totalCount={totalCount}
        filteredPlayers={filteredPlayers}
      />

      {/* Advice Modal mit Debug */}
      <AdviceDialog
        open={adviceOpen}
        onClose={() => setAdviceOpen(false)}
        loading={adviceLoading}
        advice={advice}
        error={adviceError}
        debug={adviceDebug}
      />

      {/* API Key Modal mit Validierungsstatus */}
      <ApiKeyDialog
        open={keyDialogOpen}
        onClose={() => {
          setKeyDialogOpen(false)
          setPendingAskAfterKey(false)
          setKeyValidationError('')
          setKeyValidating(false)
        }}
        onSaved={handleKeySaved}
        validating={keyValidating}
        validationError={keyValidationError}
      />
    </section>
  )
}
