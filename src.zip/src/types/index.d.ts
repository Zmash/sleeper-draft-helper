/**
 * Placeholder for future TypeScript types.
 * Example:
 * export interface Player { id: string; name: string; pos: string; team?: string; }
 */
