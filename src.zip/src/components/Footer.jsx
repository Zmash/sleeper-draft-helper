export default function Footer() {
    return (
      <footer className="muted text-xs mt-6">
        SleeperDraftHelper byZmash
      </footer>
    )
  }
  